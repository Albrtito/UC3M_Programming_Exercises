def change_of_currency(original: str, target: str, quantity: float):
    currencies = (1, 1.03, 0.0072, 1.18)
    currencies_dictionary = {"dollar": 0, "euro": 1, "yen": 2, "pound": 3}
    original_position = currencies_dictionary.get(original)
    target_position = currencies_dictionary.get(target)
    exchange = currencies[original_position]/currencies[target_position]
    final_money = quantity * exchange
    return final_money

original_currency = input("Enter the original currency: ")
target_currency = input("Enter the target currency: ")
quantity_to_change = float(input("Enter the quantity to change as a float: "))
changed_money = change_of_currency(original_currency, target_currency, quantity_to_change)
print(changed_money)