var_1 = 2
print(var_1)
var_1 = 3.4
print(var_1)
var_1 = "Hello"
print(var_1)

#The variable type makes no difference
#It is possible