#Declare all five
# variables of different
# data types

var_1 = 5
var_2 = 5.5
var_3 = "5"
var_4 = True
var_5 = 3+3j

#Print their values
print(var_1)
print(var_2)
print(var_3)
print(var_4)
print(var_5)

"""
because of python being a dynamic type
language we dont need to specify the
variable type
"""
