var_1 = int()
"""""
The variable is stored in memory 
however the value stored is automatically 
null (0)
Python is dynamic, the declaration 
and initialization of the variable 
are done in one step. However we can also 
assign a variable a non value, giving it no 
value 
"""
var_1 = None
print(var_1)