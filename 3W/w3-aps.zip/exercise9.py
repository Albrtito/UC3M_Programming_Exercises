var_1 = str("Hello")
var_2 = str("World")
var_3 = var_1 + var_2
print (var_3)
var_3 = var_1 - var_2
print(var_3)
"""
The sum of two strings gives as result both strings combined one after the other. 
We cant subtract strings, we will get a TypeError as the - operand is not supported for 
strings
"""

