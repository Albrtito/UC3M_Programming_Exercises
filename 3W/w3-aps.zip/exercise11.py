var_1 = """Twinkle, twinkle, little star, 
\n\thow I wonder what you are!
\n\t\tUp above the world so high,
\n\t\tlike a diamond in the sky.
\nTwinkle,twinkle, little star,
\n\thow I wonder what you are"""
var_2 = var_1[0:30]
var_3 = var_1[60:90]
var_4 = var_1[152:180]

print(var_2)
print(var_3)
print(var_4)