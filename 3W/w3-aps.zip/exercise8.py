""""
var_1 = int(5)
var_2 = int(0)
var_3 = var_1/var_2
print(var_3)
"""
#There will be a ZeroDivisionError as you can´t divide a number by zero

var_1 = float(5)
var_2 = float(0)
var_3 = var_1/var_2
print(var_3)

#Same error will happen if we use float instead of integers