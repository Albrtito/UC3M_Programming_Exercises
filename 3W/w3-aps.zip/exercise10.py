var_1 = """Twinkle, twinkle, little star, 
\n\thow I wonder what you are!
\n\t\tUp above the world so high,
\n\t\tlike a diamond in the sky.
\nTwinkle,twinkle, little star,
\n\thow I wonder what you are"""
print (var_1)