var_1 = int(1)
var_1 = "Hello"
print(var_1)
"""
It is possible to change the variable content to hello
without an error. This is because python is an inferred type language
"""