var_1 , var_2 , var_3 = 2, "Hello", 2.3
print(var_1)
print(var_2)
print(var_3)

#It is posible to delcare more than one variable in the same line, the variables
#can be of different types