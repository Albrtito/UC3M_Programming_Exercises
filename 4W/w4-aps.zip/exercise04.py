input_1 = int(input("Write first integer number: "))
input_2 = int(input("Write second integer number: "))
if input_2 != 0:
    print(input_1 / input_2)

else:
    print("Cannot divide by zero")