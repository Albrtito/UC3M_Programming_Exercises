a = 4
a += 2
print(a)
a -= 3
print(a)
a *= 3
print(a)
a /= 2
print(a)
a %= 4
print(a)
a == 0
print(a)
a //= 2
print(a)

"""
After we assign a value to a, we can reasign values to the variable with commands such
as: a = a +3. However, instead having to write a again just to add 3 to the variable 
we can use += to say that the variable is equal to itself plus 3. Same thing happens 
with all the operators. 
The only statement that seems to have no effect is the == statement. 
"""

