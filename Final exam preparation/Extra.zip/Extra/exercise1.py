# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 10:58:48 2019

@author: Angel Garcia Olaya PLG-UC3M
@version: 1.0
"""

import random


def random_list(size: int, lower: float, upper: float) -> list:
    """Randomly fills a list of size with values between lower and upper"""
    result = []
    for index in range(size):
        element = random.uniform(lower, upper)
        result.append(element)
    return result


def totally_random_list() -> list:
    """Generates a random list of [1,10000) size with random values in that range"""
    size = random.randrange(1, 10000)
    lower = random.randrange(1, 10000)
    upper = random.randrange(1, 10000)
    # As we have already a function doing the job, we invoke it
    return random_list(size, lower, upper)


def manual_list():
    """Fills a list manually"""
    result = []
    size = int(input("Enter the size of the list: "))
    for index in range(size):
        element = float(input("Enter the element %i " % (index + 1)))
        result.append(element)
    return result


def shrink_list(lst: list) -> list:
    """ adds the elements of the list by pairs and returns a new list"""
    result = []
    if len(lst) % 2 == 0:
        maximum = len(lst)
    else:
        maximum = len(lst) - 1
    for index in range(0, maximum, 2):
        result.append(lst[index] + lst[index + 1])
    if maximum < len(lst):
        result.append(lst[maximum])
    return result


def invert_list(lst: list) -> list:
    """ Reverses the list"""
    result = []
    for index in range(len(lst)-1, -1, -1):
        result.append(lst[index])
    return result


def print_list(lst: list):
    """ prints the list truncating the float values"""
    for element in lst:
        print(int(element), end=" ")
    print()


# Main program
option = 0
ls = []
while option < 1 or option > 3:
    print('How do you want to fill the list?')
    print('1) Partially random')
    print('2) Totally random')
    print('3) Manually')
    option = int(input())
    if option < 1 or option > 3:
        print('Please, enter 1, 2 or 3!')
    elif option == 1:
        elem = int(input("Enter the number of elements "))
        upp = int(input("Enter the upper bound "))
        low = int(input("Enter the lower bound "))
        ls = random_list(elem, low, upp)
    elif option == 2:
        ls = totally_random_list()
    else:
        ls = manual_list()


print("The list is ", ls)
action = ''
while action != "C":
    print("Enter the option")
    print("A) Shrink the array")
    print("B) Invert the array")
    print("C) Quit")
    action = input()
    if action not in "ABC":
        print("Enter a right option!")
    elif action == 'A':
        print_list(shrink_list(ls))
    elif action == 'B':
        print_list(invert_list(ls))
print("Thanks")