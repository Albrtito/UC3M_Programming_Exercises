class ATM:
    
    def __init__(self, bank, address, balance):
        self.bank = bank
        self.address = address
        self.balance = balance


    @property
    def balance(self):
        return self.__balance

    @balance.setter
    def balance(self, money):
        if type(money) != float and type(money) != int:
            raise TypeError("It must be a number")
        elif money >= 0:
            self.__balance = money
        else:
            raise ValueError("It must be positive")


    def withdrawMoney(self, client, money):
        # Looking for an account in this bank's ATM
        account = None
        for i in client.accounts:
            # If he has more than one, the last one will be selected
            if i.bank == self.bank:
                account = i
        if account is None:
            print("Error the client has no account in this bank")
        elif account.balance < money:
            print("Not enough money in your account")
        elif self.balance < money:
            print("Not enough money in the ATM")
        else:
            self.balance -= money
            account.balance -= money
            print("Here you are ", money, "euros")
            print("Your current balance in this account is", account.balance)

    def fillATM(self, money):
        self.balance += money