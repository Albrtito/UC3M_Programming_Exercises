from account import Account

class Client:

    def __init__(self, i:str, address:str , name:str):
        self.id = i
        self.address = address
        self.name = name
        self.accounts = []


    @property
    def accounts(self):
        return self.__accounts

    @accounts.setter
    def accounts(self, account: Account):
        # To be able to assign the empty list at the beginning we need to
        # put it here too
        if account == []:
            self.__accounts = account
        elif type(account) != Account:
            raise TypeError("It must be an Account object")
        elif len(self.__accounts) < 5:
            self.__accounts.append(account)
        else:
            raise ValueError("Max of 5 accounts for a client")
