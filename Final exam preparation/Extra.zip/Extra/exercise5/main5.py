from account import Account
from client import Client
from atm import ATM

# We could have also created a bank class that has inside it ATM but as
# there are no methods for it, we will use just the names

atm1 = ATM("la caixa", "Calle Cuenca", 10000)
atm2 = ATM("bbva", "Calle Toledo", 20000)
atm3 = ATM("santander", "Calle Sepúlveda", 30000)

client1 = Client(4747, "Avenida de algo", "Ines")
client2 = Client(2, "Sesame st.", "Aurora")


account1 = Account("la caixa", 1234, 1234, 5000)
account2 = Account("bbva", 1234, 1234, 10000)
account3 = Account("santander", 1234, 1234, 15000)


# This will append the accounts to the clients
client1.accounts = account1
client1.accounts = account2
client2.accounts = account3


atm1.withdrawMoney(client2, 100)
atm3.withdrawMoney(client2, 100)
atm1.withdrawMoney(client1, 200)

print("Balance in ATM1:", atm1.balance)
print("Balance in ATM2:", atm2.balance)
print("Balance in ATM3:", atm3.balance)
