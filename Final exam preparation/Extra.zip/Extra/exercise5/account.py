class Account:
    
    def __init__(self, bank:str, i:str, card:int, balance:float):
        self.bank = bank
        self.id = i
        self.card = card
        self.balance = balance

    @property
    def balance(self):
        return self.__balance

    @balance.setter
    def balance(self, money):
        if type(money) != float and type(money) != int:
            raise TypeError("It must be a number")
        else:
            # It can be negative too
            self.__balance = money
