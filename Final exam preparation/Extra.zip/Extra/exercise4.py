#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 11:44:56 2018

@author: yolanda
"""

import random


def playCards(n) -> list:
    cards = []
    while n > 0:
        cards.append(random.randrange(1, 11))
        n -= 1
    return cards


def sortCardList(cards):
    aux = 0
    for i in range(1, len(cards)):
        for j in range(0, len(cards) - i):
            if cards[j] > cards[j + 1]:
                aux = cards[j + 1]
                cards[j + 1] = cards[j]
                cards[j] = aux


def checkStraight(cards):
    consecutive = 1
    for i in range(0, len(cards) - 1):
        if cards[i+1] == cards[i]+1:
            consecutive += 1
        else:
            consecutive = 1
    if consecutive == 4:
        print('There is a straight')
        return True
    return False


def checkWinningCombinations(cards):
    repeated = []
    trios = 0
    pairs = 0
    for item in cards:
        if item not in repeated:
            n = cards.count(item)
            if n == 2:
                pairs += 1
            elif n == 3:
                trios += 1
            repeated.append(item)
    if pairs > 0:
        print('There are %i pairs' % pairs)
    if trios > 0:
        print('There are %i trios' % trios)

    return pairs > 0 or trios > 0


# main program
cardsPerRound = int(input('Cards per round? '))
badRounds = int(input('Bad rounds? '))

while badRounds > 0:
    cards = playCards(cardsPerRound)
    sortCardList(cards)
    print(cards)
    straight = checkStraight(cards)
    winning = checkWinningCombinations(cards)
    if not winning and not straight:
        print('Bad round')
        badRounds -= 1
