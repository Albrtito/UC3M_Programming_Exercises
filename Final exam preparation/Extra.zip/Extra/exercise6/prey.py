"""
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/17
Version 1.0
"""
# we are not using inheritance but it would be a good idea to use it for
# preys and hunters
import random


class Prey:
    def __init__(self, x, y, id):
        self.x = x
        self.y = y
        # 0 up, 1 right, 2 down, 3 left
        self.direction = random.randrange(0, 4)
        self.id = id

    @property
    def x(self):
        return self.__x

    @x.setter
    def x(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 0:
            raise ValueError("It must be >= 0")
        else:
            self.__x = value

    @property
    def y(self):
        return self.__y

    @y.setter
    def y(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 0:
            raise ValueError("It must be >= 0")
        else:
            self.__y = value

    def move(self, sizeX, sizeY):
        """Moves the prey randomly, if the borders are reached it bounds. Only
	        alive preys move
	        @param sizeX the size of the board
	        @param sizeY the size of the board"""
        # 0 keeps the direction, 1 turns right, 2 stays put, 3 turns left
        new_dir = random.randrange(0, 4)
        # if new_dir == 2 we do nothing this turn
        if new_dir != 2:
            # Turning right is equivalent to add 1 to the moving Direction
            if new_dir == 1:
                self.direction += 1
                # 	If current value is 4 we set it to 0
                if self.direction == 4:
                    self.direction = 0
            # Turning left, is like subtracting 1
            elif new_dir == 2:
                self.direction -= 1
                # 	If current value is -1 we set it to 3
                if self.direction == -1:
                    self.direction = 3
            # Now moving
            if self.direction == 0:
                # If we move up and are at position 0, we bounce and change
                # our moving direction to down
                if self.y == 0:
                    self.y = 1
                    self.direction = 2
                else:
                    self.y -= 1
            elif self.direction == 1:
                # If we are moving right and we reach the limit, we bounce
                # and change the moving direction to left
                if self.x == sizeX - 1:
                    self.x -= 1
                    self.direction = 3
                else:
                    self.x += 1
            elif self.direction == 2:
                # If we are moving down and reach the limit, we bounce
                # and change the moving direction to up
                if self.y == sizeY - 1:
                    self.y -= 1
                    self.direction = 0
                else:
                    self.y += 1
            else:
                # If we move left and are at position 0, we bounce and change
                # our moving direction to right
                if self.x == 0:
                    self.x == 1
                    self.direction = 1
                else:
                    self.x -= 1

    def __str__(self):
        return 'prey ' + str(self.id) +": (" + str(self.x) + "," + str(
            self.y) +")"