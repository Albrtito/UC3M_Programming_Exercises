""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/17
Version 1.0
"""
import random
from hunter import Hunter
from prey import Prey

class Board:
    def __init__(self, x: int, y:int, preys: int):
        self.turns = 0
        self.x = x
        self.y = y
        # Placing the hunter
        self.hunter = Hunter (random.randrange(0,x), random.randrange(0,y))
        # Placing the preys
        self.preys = []
        if preys < 1:
            preys = 5
        for index in range(preys):
            free = False
            # To check for free positions
            while not free:
                random_x = random.randrange(0, x)
                random_y = random.randrange(0, y)
                free = True
                if random_x == self.hunter.x and random_y == self.hunter.y:
                    free = False
                for prey in self.preys:
                    if random_x == prey.x and random_y == prey.y:
                        free = False
            self.preys.append(Prey(random_x, random_y, index))

    @property
    def x(self):
        return self.__x

    @x.setter
    def x(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 2:
            raise ValueError("It must be >= 2")
        else:
            self.__x = value

    @property
    def y(self):
        return self.__y

    @y.setter
    def y(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 2:
            raise ValueError("It must be >= 2")
        else:
            self.__y = value

    def next_turn(self) -> bool:
        self.turns += 1
        # Moving preys
        for prey in self.preys:
            prey.move(self.x, self.y)
        # Hunter moves now
        self.hunter.chase(self.preys)
        # Checking end of game
        finish = False
        if len(self.preys) == 0:
            print("All the preys chased finishing")
            finish = True
        elif self.turns == 200:
            print("200 turns, preys won")
            finish = True
        return finish


    def __str__(self):
        # Creating a list and returning its str
        result = []
        for rows in range(self.y):
            result.append([])
            for columns in range(self.x):
                result[-1].append('S')
        # Adding the hunter
        result[self.hunter.y][self.hunter.x] = 'H'
        # Adding the preys
        for prey in self.preys:
            result[prey.y][prey.x] = str(prey.id)
        # Creating the str
        res = ""
        for rows in range(self.y):
            res += "\n"
            for cols in range(self.x):
                res += result[rows][cols]
        return res
