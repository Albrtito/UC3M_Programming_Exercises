""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/17
Version 1.0
"""
from board import Board

print("Enter the size of the board and the number of preys")
x = int(input())
y = int(input())
p = int(input())
bo = Board(x,y,p)

print("Initial board")
print(bo)

while not bo.next_turn():
    print("\nTurn:", bo.turns)
    print(bo.hunter)
    for prey in bo.preys:
        print(prey)
    print(bo)