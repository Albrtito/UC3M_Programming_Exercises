from prey import Prey

""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/17
Version 1.0
"""
# we are not using inheritance but it would be a good idea to use it for
# preys and hunters
class Hunter:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    @property
    def x(self):
        return self.__x
    @x.setter
    def x(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 0:
            raise ValueError("It must be >= 0")
        else:
            self.__x = value

    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self, value):
        if type(value) != int:
            raise TypeError("It must be an integer")
        elif value < 0:
            raise ValueError("It must be >= 0")
        else:
            self.__y = value

    def closest_prey (self, preys: list) -> Prey:
        """ Returns the closest prey to the hunter"""
        closest = preys[0]
        # The distance is the difference in x and y
        min_distance = abs(self.x - preys[0].x) + abs(self.y - preys[0].y)
        for prey in preys:
            distance = abs(self.x - prey.x) + abs(self.y - prey.y)
            if distance < min_distance:
                closest = prey
                min_distance = distance
        return closest

    def move(self, closest: Prey):
        """ Moves to the closest prey"""
        if closest.x > self.x:
            self.x += 1
        elif closest.x < self.x:
            self.x -= 1
        elif closest.y > self.y:
            self.y += 1
        elif closest.y < self.y:
            self.y -= 1

    def chase (self, preys: list):
        """ Chases a prey if it is at the same position"""
        closest = self.closest_prey(preys)
        print("Chasing prey"+str(closest.id))
        self.move(closest)
        if self.x == closest.x and self.y == closest.y:
            preys.remove(closest)

    def __str__(self):
        return "hunter: (" + str(self.x) + "," + str(self.y) +")"