# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 17:02:36 2019

@author: Angel Garcia Olaya PLG-UC3M
@version: 1.0
Testing the date class
"""

from date import Date
from person import Person

# Some examples of using Date class

a = Date(1)
a.setDate('28/2/2011')
print(a)
print(a.nextDay())
b = Date(4)
b.setDate('May 27th, 2011')
print(b)
b.setFormat(2)
print(b)
print(a.isPrevious(b))
print(b.countDays(a))
print(a.print_days(b))
c = b.nextDay()
c.setFormat(4)
print(a.in_Between(b, c))
li = [c, b, a]
print(li)
a.sort_dates(li)
print(li)


def sort_by_age(aList):
    ''' This function sorts a list of persons using bubble algorithm'''
    # Variable to stop working if the list is already sorted
    swapping = True
    # number of iterations of the outer loop
    num = len(aList) - 1
    # outer loop: (elements-1) loops max
    while num > 0 and swapping:
        # At the beginning of each iteration we haven't swapped
        swapping = False
        # Inner loop (len(list)-number comparisons)
        for i in range(num):
            # if the lower index element is bigger than the next one, swap
            if aList[i].birthday.isPrevious(aList[i+1].birthday):
                # we did a change, so we update the variable
                swapping = True
                # we use aux to swap, notice that in Python we don't really
                # need this aux variable as we can do:
                # aList[i], aList[i + 1] = aList[i + 1], aList[i]
                aux = aList[i]
                aList[i] = aList[i + 1]
                aList[i + 1] = aux
        # One iteration performed, we decrease the number of pending ones
        num -= 1


def people_ages(lis, today):
    '''Returns a String as: Pepe: 2 years old, he/she has the same age as
    Juana: 2 years old, he/she is 1 year younger than Mario: 3 years old.'''
    res = ""
    sort_by_age(lis)
    for ii in range(len(lis)):
        res = res + lis[ii].name + ": " + str(lis[ii].age(today)) + ' years ' \
                                                                    'old'
        # The last element of the list is different
        if ii < len(lis)-1:
            age = lis[ii].age(today)
            age2 = lis[ii+1].age(today)
            age2 = age2-age
            if (age2 == 0):
                res = res+", he/she has the same age as "
            else:
                res = res+", he/she is "+str(age2)+" year(s) younger than "
        else:
            res = res+"."
    return res


today = Date(1)
aux = input("Which day is today? (dd/mm/yyyy) ")
today.setDate(aux)
persons = int(input("How many persons? "))
lis = []
for p in range(persons):
    print("Data of person", (str(p+1)))
    name = input("Name? ")
    bd = input("Birthday? (dd/mm/yyyy) ")
    aux = Date(1)
    aux.setDate(bd)
    lis.append(Person(name, aux))

print(people_ages(lis, today))
