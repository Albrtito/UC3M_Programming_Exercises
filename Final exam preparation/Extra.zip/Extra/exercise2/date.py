# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 12:07:05 2019

@author: Angel Garcia Olaya PLG-UC3M
@version: 1.0
A representation of the Date class for problem 2 of the extra exercises.
 Notice the problem can be also solved by using functions, with no OOP.
"""


class Date:

    def __init__(self, form):
        """ To force the user to select one of the formats, the only way to
        create objects is self"""
        # Private constants to handle date formats easily
        self.__DAY_FIRST = 1
        self.__MONTH_FIRST = 2
        self.__YEAR_FIRST = 3
        self.__TEXT = 4
        # If the format is not valid, we choose DAY_FIRST
        if (form < 0 or form > 4):
            self.format = self.__DAY_FIRST
        else:
            self.format = form

        # Private tuple with the names of the months
        self.__months = ('january', 'february', 'march', 'april', 'may',
        'june', 'july', 'august', 'september', 'october', 'november',
                         'december')
        # Private dictionary to set the days of each month
        self.__month_days = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
                             7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}
        # Despite the format we store data as numbers
        self.year = 1900
        self.month = 1
        self.day = 1

    # This @property keyword is called a 'decorator'
    @property
    def year(self):
        """ This special method will return the value of the year"""
        # Here I must return the value of my attribute as if it were
        # private, even if it is not. If I don't do it it will not
        # work
        return self.__year

    # To avoid this method replacing the previous one, it needs to be
    # decorated with @attribute.setter
    @year.setter
    def year(self, year: int):
        """ This method allows to change the value of the year"""
        # If the type is not correct we raise an exception
        if type(year) != int:
            raise TypeError("The year  must be an int")
        # Here I need to consider year again as if it were private
        elif year != 0:
            self.__year = year
        else:
            # In any other case, I raise an exception
            raise ValueError("Year must be not equal to 0")

    # For leap year we create only the property as we don´t want
    # anyone to change its value
    @property
    def leap_year(self):
        # This is a special property as it has no attribute linked to it
        # Properties allow us to create 'fake' read only attributes
        # based on other attributes
        return self.year % 4 == 0 and (self.year % 100 != 0
                                       or self.year % 400 == 0)

    # We create properties and setters also for day and month
    @property
    def month(self):
        return self.__month

    @month.setter
    def month(self, month: str):
        if type(month) != int:
            raise TypeError("The month must be a number")
        elif 1 <= month <= 12:
            self.__month = month
        else:
            raise ValueError("Valid months are 1 to 12")

    @property
    def day(self):
        return self.__day

    @day.setter
    def day(self, day: int):
        # I change the days if leap year
        if self.leap_year:
            self.__month_days[2] = 29
        if type(day) != int:
            raise TypeError("The day must be an integer")
        elif day > 0 and day <= self.__month_days[self.month]:
            self.__day = day
        else:
            raise ValueError(self.month + " has only " +
                             str(self.__month_days[self.month])
                             + " days in " + str(self.year))

    def month_name(self) -> str:
        ''' Returns the name of the month '''
        month_name = self.__months[self.month-1]
        return month_name

    def days_in_month(self) -> int:
        ''' Returns the number of days of this month'''
        return self.__month_days[self.month]

    def setDate(self, date):
        '''Sets the date receiving a string in any of the four formats. If
        either month, day or year are not correct they remain unchanged '''
        # Invoking another method to extract day, month and year
        params = self.extractParameters(date)
        self.year = int(params[0])
        self.month = int(params[1])
        self.day = int(params[2])

    def extractParameters(self, d) -> list:
        ''' Extracts the year, month and day from a Date and returns a list
        with their numeric values. We assume that the user will enter
            numbers where numbers are supposed '''
        if (self.format == self.__TEXT):
            # We are assuming there will be 3 items separated by a space, if
            # not a runtime error will appear
            result = []
            parts = d.split(" ")
            # Year is the last element
            result.append(int(parts[2]))
            # To get the number of the month, we convert the dictionary to a
            # tuple, this will create a tuple with just the keys
            month_number = self.__months.index(parts[0].lower())+1
            result.append(month_number)
            # Day is the second, but extra stuff needs to be removed
            # actually the last 3 characters need to be removed
            result.append(int(parts[1][0:-3]))

        else:
            # We are assuming there will be 3 items separated by "/", if not a
            # runtime error will appear
            parts = d.split("/")
            if self.format == self.__DAY_FIRST:
                result = [parts[2], parts[1], parts[0]]
            elif self.format == self.__MONTH_FIRST:
                result = [parts[2], parts[0], parts[1]]
            else:
                result = [parts[0], parts[1], parts[2]]
        return result

    def setFormat(self, form):
        ''' Converts the date to the format (changes the format field, the
        inner representation of the Date does not change). If the format is not
        correct it does nothing'''
        if (form >= self.__DAY_FIRST and form <= self.__TEXT):
            self.format = form


    def __ordinalMark(self, n: int) -> str:
        ''' Private method that returns the ordinal mark for a given number
        (st,nd,rd,th) '''
        if (n > 3 and n < 21):
            return "th"
        # Converting it to String to make it easier
        number = str(n)
        if number[-1] == '1':
            # works for 1, 21 and 31
            return "st"
        elif number[-1] == '2':
            return "nd"
        elif number[-1] == '3':
            return "rd"
        else:
            return "th"

    def __str__(self) -> str:
        ''' Returns a string representing the date in the desired format'''
        if (self.day < 10):
            day = "0" + str(self.day)
        else:
            day = str(self.day)
        # To get the number of the month, we convert the dictionary to a tuple
        # this will create a tuple with just the keys
        if (self.month < 9):
            month = "0" + str(self.month)
        else:
            month = str(self.month)

        if self.format == self.__DAY_FIRST:
            return day + "/" + month + "/" + str(self.year)
        elif self.format == self.__MONTH_FIRST:
            return month + "/" + day + "/" + str(self.year)
        elif self.format == self.__YEAR_FIRST:
            return str(self.year) + "/" + month + "/" + day
        else:
            return (self.month_name() + " " + str(self.day)
                    + self.__ordinalMark(self.day) + ", " + str(self.year))

    def __repr__(self):
        return self.__str__()

    def nextDay(self):
        ''' Returns the next day after the current one'''
        # Creating a new Date object with the data of this one
        nxt = Date(self.format)
        nxt.day = self.day
        nxt.month = self.month
        nxt.year = self.year
        if nxt.day < nxt.days_in_month():
            nxt.day += 1
        else:
            nxt.day = 1
            if nxt.month < 12:
                nxt.month += 1
            else:
                nxt.month = 1
                nxt.year += 1
        return nxt

    def isPrevious(self, d) -> bool:
        '''Returns true is this date is previous to the parameter one'''
        return (self.year < d.year
                or (self.year == d.year
                    and (self.month < d.month
                         or (self.month == d.month and self.day < d.day))))

    def countYears(self, other) -> int:
        ''' Counts the years between this date and the parameter.'''
        return abs(self.year-other.year)

    def __days_to_date(self, other) -> int:
        ''' Private method to chek the days between to dates of the same year.
        The second will always be >= than the first'''
        # If they belong to the same month
        if self.month == other.month:
            return other.day - self.day
        else:
            days = 0
            # Till the end of the month
            days += self.days_in_month()-self.day
            # From the beginning of the second month
            days += other.day
            # Days in between
            month_days = tuple(self.__month_days.values())
            for m in range(self.month + 1, other.month):
                days += month_days[m]
        return days

    def countDays(self, d) -> int:
        ''' Counts the days between two dates'''
        # We put first the oldest date
        if self.isPrevious(d):
            first = self
            second = d
        else:
            first = d
            second = self
        # If they belong to the same year, we just count the days using the
        # previous method
        if (first.year == second.year):
            return first.__days_to_date(second)
        # If not, we will count first the days to the end of the year for the
        # earliest date of both, plus the days from the beginning of the year
        # for the latest date of both
        # Days from the first date until the end of the year
        aux = Date(self.__DAY_FIRST)
        aux.setDate('31/12/'+str(self.year))
        days = first.__days_to_date(aux) + 1
        # Days from the beginning of the year until second object's date
        aux.setDate('1/1/'+str(d.year))
        days += aux.__days_to_date(second)
        # We counted the days of first.year until the end of the year, so we
        # start in the next year
        startingYear = first.year + 1
        endYear = second.year
        # Now we count days in whole years
        for ii in range(startingYear, endYear):
            if ii % 4 == 0 and (ii % 100 != 0 or ii % 400 == 0):
                days += 366
            else:
                days += 365
        return days

    def print_days(self, d) -> list:
        '''Returns a list with all the days between self and the parameter'''
        res = []
        # We put first the oldest date
        if self.isPrevious(d):
            first = self
            second = d
        else:
            first = d
            second = self
        # And now append elements to the list
        while first.isPrevious(second):
            first = first.nextDay()
            res.append(first)
        return res

    def in_Between(self, d1, d2) -> bool:
        '''Returns true if self date is between the two ones passed as
        parameters'''
        if d1.isPrevious(self) and self.isPrevious(d2):
            return True
        else:
            return False

    def sort_dates(self, aList):
        ''' This function sorts a list of dates using bubble algorithm'''
        # Variable to stop working if the list is already sorted
        swapping = True
        # number of iterations of the outer loop
        num = len(aList) - 1
        # outer loop: (elements-1) loops max
        while num > 0 and swapping:
            # At the beginning of each iteration we haven't swapped
            swapping = False
            # Inner loop (len(list)-number comparisons)
            for i in range(num):
                # if the lower index element is bigger than the next one, swap
                if aList[i + 1].isPrevious(aList[i]):
                    # we did a change, so we update the variable
                    swapping = True
                    # we use aux to swap, notice that in Python we don't really
                    # need this aux variable as we can do:
                    # aList[i], aList[i + 1] = aList[i + 1], aList[i]
                    aux = aList[i]
                    aList[i] = aList[i + 1]
                    aList[i + 1] = aux
            # One iteration performed, we decrease the number of pending ones
            num -= 1
