# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 17:28:51 2019

@author: Angel Garcia Olaya PLG-UC3M
@version: 1.0
"""
from date import Date


class Person:

    def __init__(self, name, birthday):
        self.name = name
        self.birthday = birthday

    def age(self, today):
        return self.birthday.countYears(today)

    def older(self, other):
        if self.birthday.isPrevious(other.birthday):
            return 1
        elif other.birthday.isPrevious(self.birthday):
            return -1
        else:
            return 0
