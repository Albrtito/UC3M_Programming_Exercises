#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 11:44:56 2018

@author: yolanda
"""

import random
from timestamp import Timestamp


class Measure:

    def __init__(self):
        self.timestamp = Timestamp(random.randrange(0, 25),
                                   random.randrange(0, 61),
                                   random.randrange(0, 61))


# We use inheritance, notice this should be in another file
class Temperature(Measure):

    def __init__(self):
        super().__init__()
        self.temperature = random.randrange(-60, 60)

    def __str__(self):
        res = str(self.temperature) + ' degrees at ' + str(self.timestamp)
        return res



class Pressure(Measure):

    def __init__(self):
        super().__init__()
        self.pressure = random.randrange(760, 1087)

    def __str__(self):
        res = str(self.pressure) + ' mb at ' + str(self.timestamp)
        return res
