#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 11:44:56 2018

@author: yolanda
"""


class Timestamp:

    def __init__(self, hour, minute, second):
        # We should use properties here
        if hour < 0 or hour > 23:
            self.hours = 0
        else:
            self.hours = hour
        if minute < 0 or minute > 59:
            self.minutes = 0
        else:
            self.minutes = minute
        if second < 0 or second > 59:
            self.seconds = 0
        else:
            self.seconds = second

    def addZero(self, digit):
        if digit < 10:
            return '0' + str(digit)
        else:
            return '' + str(digit)

    def before(self, other):
        return (self.hours < other.hours or
                (self.hours == other.hours
                 and (self.minutes < other.minutes
                      or (self.minutes == other.minutes
                          and self.seconds < other.seconds))))

    def secondsTo(self, other):
        sec1 = self.hours * 3600 + self.minutes * 60 + self.seconds
        sec2 = other.hours * 3600 + other.minutes * 60 + other.seconds
        return sec2 - sec1

    def __str__(self):
        s = (self.addZero(self.hours) + ':' + self.addZero(self.minutes)
             + ':' + self.addZero(self.seconds))
        return s
