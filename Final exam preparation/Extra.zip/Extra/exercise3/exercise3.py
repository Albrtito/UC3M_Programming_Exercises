#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 11:44:56 2018

@author: yolanda
"""

from station import Station
from measure import Measure
from timestamp import Timestamp


def readInteger() -> int:
    read = False
    while not read:
        n = int(input('Enter a positive integer number '))
        if n >= 0:
            read = True
    return n


def printMenu():
    print('Enter one option please')
    print('1. Create new temperature measures')
    print('2. Create new pressure measures')
    print('3. Recover the temperature measure closest to a timestamp')
    print('4. Recover a temperature measure by its position')
    print('5. Recover all temperature measures')
    print('6. Recover the pressure measure closest to a timestamp')
    print('7. Recover a pressure measure by its position')
    print('8. Recover all pressure measures')
    print('9. See the current values of temperature and pressure')
    print('10. See the mean values of temperature and pressure')
    print('11. Quit')
    return int(input())

# main


idNumber = int(input('Enter the id of the Weather Station '))
location = input('Enter the location of the Weather Station ')
measuresHour = int(input('Enter the number of measures per hour '))

station = Station(idNumber, location, measuresHour)

condition = False

while not condition:
    option = printMenu()
    if option == 1:
        n = int(input('How  many measures do you want to create? '))
        if not station.addMeasures(True, n):
            print('Sorry  not all measures have been created, list full')
        print(station)
    elif option == 2:
        n = int(input('How  many measures do you want to create? '))
        if not station.addMeasures(False, n):
            print('Sorry  not all measures have been created, list full')
        print(station)
    elif option == 3:
        time = input('Enter a timestamp hh:mm:ss ')
        t = time.split(':')
        timestamp = Timestamp(int(t[0]), int(t[1]), int(t[2]))
        tempM = station.readTemperatureTS(timestamp)
        print('The measure selected is ', tempM)
        print(station)
    elif option == 4:
        pos = int(input('Enter a position: '))
        tempM = station.readTemperatureP(pos)
        print('The measure selected is ', tempM)
        print(station)
    elif option == 5:
        pressure = station.readTemperature()
        print(station)
    elif option == 6:
        time = input('Enter a timestamp hh:mm:ss ')
        t = time.split(':')
        timestamp = Timestamp(int(t[0]), int(t[1]), int(t[2]))
        presM = station.readPressureTS(timestamp)
        print('The measure selected is ', presM)
        print(station)
    elif option == 7:
        pos = int(input('Enter a position: '))
        presM = station.readPressureP(pos)
        print('The measure selected is ', presM)
        print(station)
    elif option == 8:
        pressure = station.readPressure()
        print(station)
    elif option == 9:
        print(station)
    elif option == 10:
        print('Mean temperature ', station.meanTemperature)
        print('Mean pressure ', station.meanPressure)
    else:
        print('Thanks!')
        condition = True
