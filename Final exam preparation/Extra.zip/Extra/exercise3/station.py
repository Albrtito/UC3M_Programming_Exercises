#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 11:44:56 2018

@author: yolanda
"""

import measure


class Station:

    def __init__(self, idStation, location, hour):
        self.idStation = idStation
        self.location = location
        # A better idea is to use property and setter for it
        if hour > 0:
            self.measurePerHour = hour
        else:
            self.measurePerHour = 1
        self.temperatures = []
        self.pressures = []
        self.meanTemperature = 0.0
        self.meanPressure = 0.0
        self.maxMeasures = 24 * self.measurePerHour

    def createMeasure(self, measureType: bool) -> bool:
        """ Creates a measure, if measureType is true creates a temperature
        one, if not, creates a pressure one. Returns if the measure was
        created or if the list of measures is full"""
        if measureType:
            if len(self.temperatures) < self.maxMeasures:
                measureT = measure.Temperature()
                self.temperatures.append(measureT)
                return True
            else:
                return False
        else:
            if len(self.pressures) < self.maxMeasures:
                measureP = measure.Pressure()
                self.pressures.append(measureP)
                return True
            else:
                return False

    def addMeasures(self, measureType: bool, number: int) -> bool:
        """ Creates number measures of the type selected. Returns true if
        all were created, false if the list was full"""
        added, i = True, 0
        while added and i < number:
            added = self.createMeasure(measureType)
            i += 1
        self.calculateMean(measureType)
        if measureType:
            self.sortMeasure(self.temperatures)
        else:
            self.sortMeasure(self.pressures)
        return added

    def calculateMean(self, measureType):
        if measureType and len(self.temperatures) > 0:
            meanT = 0
            for t in self.temperatures:
                meanT += t.temperature
            self.meanTemperature = meanT / len(self.temperatures)
        elif len(self.pressures) > 0:
            meanP = 0
            for p in self.pressures:
                meanP += p.pressure
            self.meanPressure = meanP / len(self.pressures)

    def sortMeasure(self, aList):
        ''' This function sorts a list of measures using bubble algorithm'''
        # Variable to stop working if the list is already sorted
        swapping = True
        # number of iterations of the outer loop
        num = len(aList) - 1
        # outer loop: (elements-1) loops max
        while num > 0 and swapping:
            # At the beginning of each iteration we haven't swapped
            swapping = False
            # Inner loop (len(list)-number comparisons)
            for i in range(num):
                # if the lower index element is bigger than the next one, swap
                if not aList[i].timestamp.before(aList[i + 1].timestamp):
                    # we did a change, so we update the variable
                    swapping = True
                    # we use aux to swap, notice that in Python we don't really
                    # need this aux variable as we can do:
                    # aList[i], aList[i + 1] = aList[i + 1], aList[i]
                    aux = aList[i]
                    aList[i] = aList[i + 1]
                    aList[i + 1] = aux

    def readTemperatureTS(self, timeStamp):
        if len(self.temperatures) == 0:
            return
        closest = abs(self.temperatures[0].timestamp.secondsTo(timeStamp))
        found = False
        pos, i = 0, 0
        while not found and i < len(self.temperatures):
            current = abs(self.temperatures[i].timestamp.secondsTo(timeStamp))
            if current <= closest:
                closest = current
                read = self.temperatures[i]
                pos = i
            else:
                found = True
            i += 1
        del self.temperatures[pos]
        self.calculateMean(True)
        return read

    def readTemperatureP(self, pos):
        if pos >= 0 and pos < len(self.temperatures):
            read = self.temperatures[pos]
            del self.temperatures[pos]
            self.calculateMean(True)
            return read

    def readTemperature(self):
        read = []
        for t in self.temperatures:
            read.append(t)
        self.temperatures.clear()
        self.calculateMean(True)
        return read

    def readPressureTS(self, timeStamp):
        if len(self.pressures) == 0:
            return
        closest = abs(self.pressures[0].timestamp.secondsTo(timeStamp))
        found = False
        pos, i = 0, 0
        while not found and i < len(self.pressures):
            current = abs(self.pressures[i].timestamp.secondsTo(timeStamp))
            if current <= closest:
                closest = current
                read = self.pressures[i]
                pos = i
            else:
                found = True
            i += 1
        del self.pressures[pos]
        self.calculateMean(False)
        return read

    def readPressureP(self, pos):
        if pos >= 0 and pos < len(self.pressures):
            read = self.pressures[pos]
            del self.pressures[pos]
            self.calculateMean(False)
            return read

    def readPressure(self,):
        read = []
        for p in self.pressures:
            read.append(p)
        self.pressures.clear()
        self.calculateMean(False)
        return read

    def __str__(self):
        s = 'Temperatures:\n'
        for t in self.temperatures:
            s = s + str(t) + '\n'
        s += 'Pressures:\n'
        for p in self.pressures:
            s = s + str(p) + '\n'
        return s