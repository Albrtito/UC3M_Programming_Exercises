import random

class Player:
    def __init__(self, position:str):
        self.position = position
        # As the ability is always random, we don't receive it as parameter
        # We need neither setter nor property for it
        self.ability = random.randint(1, 10)

    @property
    def position(self):
        return self.__position

    @position.setter
    def position(self, pos:str):
        positions = ("goalkeeper", "defender", "midfielder", "forward")
        if pos in positions:
            self.__position = pos
        else:
            # If the position is wrong we put goalkeeper. It is better to
            # raise an exception
            self.__position = "goalkeeper"

    def __str__(self) -> str:
        # Not asked, we include it to test the program more easily
        return self.position + ":" + str(self.ability)