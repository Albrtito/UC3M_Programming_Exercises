from player import Player
import random

class Team:
    def __init__(self, name:str):
        self.name = name
        self.starting = []
        self.substitutes = []
        self.points = 0


    def call_players(self) -> list:
        #This method could also go in the Player team, but the program
        # is easier if it goes here

        aux = []
        positions = ("goalkeeper", "defender", "midfielder", "forward")
        # We add goalkeepers first
        aux.append(Player("goalkeeper"))
        aux.append(Player("goalkeeper"))
        # We now create the other 20 randomly
        defenders = forwards = mids = False
        while not (defenders and forwards and mids):
            aux2 = []
            for player in range(20):
                pos = random.randrange(0,3)
                if pos == 0:
                    defenders = True
                elif pos == 1:
                    mids = True
                else:
                    forwards = True
                aux2.append(Player(positions[pos]))
        aux.extend(aux2)
        return aux

    def sort (self, aList):
        ''' Uses bubble sort in descending order'''
        swapping = True
        num = len(aList) - 1
        while num > 0 and swapping:
            swapping = False
            for i in range(num):
                if aList[i].ability < aList[i + 1].ability:
                    swapping = True
                    aux = aList[i]
                    aList[i] = aList[i + 1]
                    aList[i + 1] = aux
            num -= 1

    def make_team(self):
        team = self.call_players()
        # We include the best goalkeeper
        if team[0].ability > team[1].ability:
            self.starting.append(team[0])
            self.substitutes.append(team[1])
        else:
            self.starting.append(team[1])
            self.substitutes.append(team[0])
        # Removing them form the list to make it easier
        del(team[0:2])
        # Sorting by ability
        self.sort(team)
        # And now we fill the other two lists
        for index in range(len(team)):
            if index < len(team)/2:
                self.starting.append(team[index])
            else:
                self.substitutes.append(team[index])

    def abilities(self) -> tuple:
        gk = defen = mid = forw = 0
        for player in self.starting:
            if player.position == "goalkeeper":
                gk = player.ability
            elif player.position == "defender":
                defen += player.ability
            elif player.position == "midfielder":
                mid += player.ability
            else:
                forw += player.ability
        return gk, defen, mid, forw
