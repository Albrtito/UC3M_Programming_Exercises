from team import Team
from match import Match

names = ("Spain", "Sweden", "Poland", "Slovakia")
# Create the teams
teams = (Team(names[0]), Team(names[1]), Team(names[2])
        , Team(names[3]))
# Create the players
for team in teams:
    team.make_team()
# Play the matchs
match1 = Match(teams[0], teams[1])
match2 = Match(teams[2], teams[3])
match1.play_match()
match2.play_match()
# Print the results
print ("Results")
print('\t', match1)
print('\t', match2)
# Imprimir clasificación
print ("Leaderboard")
for team in teams:
    print('\t', team.name, team.points, "points")
