from team import Team
import random

class Match:
    def __init__(self, home: Team, away: Team):
        self.home = home
        self.away = away
        self.home_goals = 0
        self.away_goals = 0

    def play_match(self):
        home_ab = self.home.abilities()
        away_ab = self.away.abilities()
        home_attack = home_ab[2] + home_ab[3]
        away_attack = away_ab[2] + away_ab[3]
        home_def = home_ab[0] + home_ab[1]
        away_def = away_ab[0] + away_ab[1]
        max1 = home_attack - away_def
        max2 = away_attack - home_def
        if max1 < 20:
            max1 = 2
        else:
            max1 = 5
        if max2 < 20:
            max2 = 2
        else:
            max2 = 5
        self.home_goals = random.randint(0, max1)
        self.away_goals = random.randint(0, max2)
        if self.home_goals > self.away_goals:
            self.home.points += 3
        elif self.away_goals > self.home_goals:
            self.away.points += 3
        else:
            self.home.points += 1
            self.away.points += 1

    def __str__(self):
        return (self.home.name + " " + str(self.home_goals) + " - " +
                self.away.name + " " + str(self.away_goals))
