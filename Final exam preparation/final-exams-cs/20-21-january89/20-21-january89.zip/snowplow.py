class Snowplow:
    def __init__(self, x: int, y:int, fuel: int):
        """ Creates a snowplow object"""
        self.x = x
        self.y = y
        self.fuel = fuel