""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/19
Version 1.0
"""

from city import City

inhabitants = int(input("Number of inhabitants "))

city = City(inhabitants)
city.create_workplaces()
city.start_pandemic()
print(city)


end = False
while not end:
    inf1 = city.spread_virus_at_home()
    inf2 = city.spread_virus_at_work()
    print(inf1, "new infections at homes")
    print(inf2, "new infections at work")
    if inf1 == 0 and inf2 == 0:
        end = True
    print(city)
