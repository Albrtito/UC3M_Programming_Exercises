""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/19
Version 1.0
"""
import random


class Person:
    def __init__(self, id: int):
        self.id = id
        self.age = random.randint(0,100)
        self.vaccinated = random.randint(0,1)
        self.infected = False

    #  This method was not required but it is useful to debug the program
    def __str__(self):
        result = (self.id) + ", " + str(self.age) + " years old, "
        if self.vaccinated:
            result += "vaccinated, "
        else:
            result *= "non vaccinated, "
        if self.infected:
            result += "is infected"
        else:
            result += "is not infected"
        return result
