""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/19
Version 1.0
"""
import random
from place import Place
from person import Person

class City:
    def __init__(self, inhabitants: int):
        self.homes = []
        self.workplaces = []
        # To store the ids and the number of people created
        id = 0
        while id < inhabitants:
            capacity = random.randint(1, 10)
            home = Place("home")
            # If it is not the last home
            if capacity < inhabitants - id:
                for person in range(capacity):
                    home.members.append(Person(id+person+1))
            # If it is, we ignore the random capacity and create the people
            # as needed
            else:
                for person in range(inhabitants - id):
                    home.members.append(Person(id + person + 1))
            self.homes.append(home)
            id += capacity

    def number_of_people(self, age1: int, age2: int) -> int:
        result = []
        for home in self.homes:
            for person in home.members:
                if age1 <= person.age <= age2:
                    result.append(person)
        return result

    def create_workplaces(self):
        working_people = self.number_of_people(26, 67)
        workplaces = len(working_people) // 10 + 1
        # Adding the workplace
        for counter in range(workplaces):
            self.workplaces.append(Place("workplace"))
        # Adding the people
        for person in working_people:
            place = random.randrange(0,workplaces)
            self.workplaces[place].members.append(person)

    def spread_virus_at_work(self) -> int:
        new_infections = 0
        for workplace in self.workplaces:
            infected = 0
            for person in workplace.members:
                if person.infected:
                    infected += 1
            if infected > 0:
                for person in workplace.members:
                    if not person.infected:
                        odds = random.randrange(0, 100)
                        if ((person.vaccinated == 0 and odds < 70) or
                            (person.vaccinated == 1 and odds < 10)):
                            person.infected = True
                            new_infections += 1
        return new_infections

    def spread_virus_at_home(self) -> int:
        new_infections = 0
        for home in self.homes:
            infected = 0
            for person in home.members:
                if person.infected:
                    infected += 1
            if infected > 0:
                for person in home.members:
                    if not person.infected:
                        odds = random.randrange(0, 100)
                        if ((person.vaccinated == 0 and odds < 70) or
                            (person.vaccinated == 1 and odds < 10)):
                            person.infected = True
                            new_infections += 1
        return new_infections

    def start_pandemic(self):
        home = random.randrange(len(self.homes))
        person = random.randrange(len(self.homes[home].members))
        self.homes[home].members[person].infected = True

    def __str__(self):
        res = ""
        for home in self.homes:
            res += str(home) + "\n"
        for workplace in self.workplaces:
            res += str(workplace) + "\n"
        return res
