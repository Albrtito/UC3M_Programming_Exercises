""" 
Created by Angel Garcia Olaya. PLG-UC3M
Since 2021/12/19
Version 1.0
"""
class Place:
    def __init__(self, kind: str):
        self.kind = kind
        self.members = []

    @property
    def kind(self):
        return self.__kind

    @kind.setter
    def kind(self, kind):
        if type(kind) != str:
            raise TypeError("It must be a str")
        elif kind == "home" or kind == "workplace":
            self.__kind = kind
        else:
            raise ValueError("Types can only be home or workplace")

    def __str__(self):
        vaccinated = 0
        infected = 0
        for person in self.members:
            if person.vaccinated:
                vaccinated += 1
            if person.infected:
                infected += 1
        return (self.kind + "\tPeople: " + str(len(
            self.members))+ "\tInfected: " + str(infected) + "\tVaccinated:"
             + str(vaccinated))