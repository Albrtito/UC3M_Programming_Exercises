import math

is_digit = False
while not is_digit:
    var_1 = input("Enter a number: ")
    for letter in var_1:
        if letter.isdigit() or letter == ".":
            is_digit = True
        else:
            is_digit = False
            break
if is_digit:
    print("The square of the entered number is",float(var_1)**2)