def list_combination(list1: list, list2: list):
    for i in range(len(list2)):
        add = True
        for m in range(len(list1)):
            if list2[i] == list1[m]:
                add = False

        if add:
            list1.append(list2[i])
    return list1


list1 = [1, 2, 3, 4, 5, 6]
list2 = [2, 5, 6, 7, 8, 9]
list3 = list_combination(list1,list2)
print("list1:",list1)
print("list2:",list2)
print("Output:",list3)
